import base64
import binascii
import secrets
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
def new_key():
    return base64.b64encode(secrets.token_bytes(32)).decode('ascii')
def new_iv():
    return base64.b64encode(secrets.token_bytes(16)).decode('ascii')
def decode_base64(value):
    try:
        return base64.b64decode(value.strip(), validate=True)
    except (ValueError, binascii.Error):
        raise ValueError('Dữ liệu phải là Base64 hợp lệ.') from None
def key_iv(key_base64, iv_base64):
    key = decode_base64(key_base64)
    iv = decode_base64(iv_base64)
    if len(key) != 32 or len(iv) != 16:
        raise ValueError('Key phải có 32 byte, IV phải có 16 byte. Bấm Generate Key / Generate IV.')
    return key, iv
def encrypt_text(plaintext, key_base64, iv_base64):
    key, iv = key_iv(key_base64, iv_base64)
    padder = padding.PKCS7(128).padder()
    data = padder.update(plaintext.encode('utf-8')) + padder.finalize()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
    return base64.b64encode(cipher.update(data) + cipher.finalize()).decode('ascii')
def decrypt_text(ciphertext, key_base64, iv_base64):
    key, iv = key_iv(key_base64, iv_base64)
    data = decode_base64(ciphertext)
    if not data or len(data) % 16:
        raise ValueError('Độ dài bản mã CBC phải là bội số của 16 byte.')
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    padded = cipher.update(data) + cipher.finalize()
    try:
        unpadder = padding.PKCS7(128).unpadder()
        return (unpadder.update(padded) + unpadder.finalize()).decode('utf-8')
    except (ValueError, UnicodeDecodeError):
        raise ValueError('Giải mã thất bại: sai Key/IV hoặc bản mã bị sửa.') from None
def to_file(iv, ciphertext):
    if len(decode_base64(iv)) != 16:
        raise ValueError('IV phải có 16 byte.')
    data = decode_base64(ciphertext)
    if not data or len(data) % 16:
        raise ValueError('Bản mã CBC không hợp lệ.')
    return 'IV=' + iv.strip() + '\n' + ciphertext.strip() + '\n'
def from_file(content):
    parts = content.strip().splitlines()
    if len(parts) != 2 or not parts[0].startswith('IV='):
        raise ValueError('Tệp phải có dòng 1 là IV=..., dòng 2 là bản mã.')
    iv, ciphertext = parts[0][3:].strip(), parts[1].strip()
    to_file(iv, ciphertext)
    return iv, ciphertext
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('AES-CBC Python - LAB 2')
        self.resizable(False, False)
        frame = ttk.Frame(self, padding=14)
        frame.grid()
        ttk.Label(frame, text='BÀI NÂNG CAO 02 - AES-256-CBC (PYTHON)', font=('Segoe UI', 14, 'bold')).grid(row=0, column=0, columnspan=3, sticky='w', pady=(0, 8))
        ttk.Label(frame, text='Plaintext:').grid(row=1, column=0, sticky='nw')
        self.txt_plain = tk.Text(frame, width=64, height=5, wrap='word')
        self.txt_plain.grid(row=1, column=1, columnspan=2, pady=3)
        self.key = tk.StringVar()
        self.iv = tk.StringVar()
        for row, caption, value, command in [(2, 'Key (Base64):', self.key, lambda: self.key.set(new_key())),
                                             (3, 'IV (Base64):', self.iv, lambda: self.iv.set(new_iv()))]:
            ttk.Label(frame, text=caption).grid(row=row, column=0, sticky='w')
            ttk.Entry(frame, textvariable=value, width=60).grid(row=row, column=1, sticky='w', pady=3)
            ttk.Button(frame, text='Generate Key' if row == 2 else 'Generate IV', command=command).grid(row=row, column=2, sticky='ew')
        ttk.Label(frame, text='Ciphertext:').grid(row=4, column=0, sticky='nw')
        self.txt_cipher = tk.Text(frame, width=64, height=5, wrap='char')
        self.txt_cipher.grid(row=4, column=1, columnspan=2, pady=3)
        buttons = ttk.Frame(frame)
        buttons.grid(row=5, column=1, columnspan=2, sticky='w', pady=6)
        for text, command in [('Encrypt', self.encrypt), ('Decrypt', self.decrypt), ('Save File', self.save), ('Open File', self.open)]:
            ttk.Button(buttons, text=text, command=command).pack(side='left', padx=(0, 8))
        self.status = tk.StringVar(value='Bấm Generate Key và Generate IV trước.')
        ttk.Label(frame, textvariable=self.status).grid(row=6, column=1, columnspan=2, sticky='w')
        self.update_idletasks()
        self.geometry(f'+{(self.winfo_screenwidth() - self.winfo_width()) // 2}+{(self.winfo_screenheight() - self.winfo_height()) // 2}')
    def get_text(self, widget):
        return widget.get('1.0', 'end-1c')
    def set_text(self, widget, value):
        widget.delete('1.0', 'end')
        widget.insert('1.0', value)
    def encrypt(self):
        try:
            self.set_text(self.txt_cipher, encrypt_text(self.get_text(self.txt_plain), self.key.get(), self.iv.get()))
            self.status.set('Đã mã hóa AES-CBC.')
        except ValueError as ex:
            messagebox.showerror('Lỗi', str(ex), parent=self)
    def decrypt(self):
        try:
            self.set_text(self.txt_plain, decrypt_text(self.get_text(self.txt_cipher), self.key.get(), self.iv.get()))
            self.status.set('Đã giải mã AES-CBC.')
        except ValueError as ex:
            messagebox.showerror('Lỗi', str(ex), parent=self)
    def save(self):
        try:
            content = to_file(self.iv.get(), self.get_text(self.txt_cipher))
            path = filedialog.asksaveasfilename(parent=self, defaultextension='.txt', initialfile='aes_cbc_ciphertext.txt', filetypes=[('Text file', '*.txt')])
            if path:
                Path(path).write_text(content, encoding='utf-8')
                self.status.set('Đã lưu: ' + path)
        except (OSError, ValueError) as ex:
            messagebox.showerror('Lỗi lưu tệp', str(ex), parent=self)
    def open(self):
        path = filedialog.askopenfilename(parent=self, filetypes=[('Text file', '*.txt')])
        if not path:
            return
        try:
            iv, ciphertext = from_file(Path(path).read_text(encoding='utf-8'))
            self.iv.set(iv)
            self.set_text(self.txt_cipher, ciphertext)
            self.status.set('Đã mở tệp. Nhập đúng Key rồi bấm Decrypt.')
        except (OSError, ValueError) as ex:
            messagebox.showerror('Lỗi mở tệp', str(ex), parent=self)
def self_test():
    key, iv = new_key(), new_iv()
    for text in ['Xin chào AES-CBC', '', '1234567890123456', 'Văn bản dài tiếng Việt có dấu. ' * 200]:
        assert decrypt_text(encrypt_text(text, key, iv), key, iv) == text
    ciphertext = encrypt_text('abc', key, iv)
    assert len(decode_base64(ciphertext)) == 16
    restored_iv, restored_cipher = from_file(to_file(iv, ciphertext))
    assert decrypt_text(restored_cipher, key, restored_iv) == 'abc'
    for bad in ['%%%', base64.b64encode(b'123').decode('ascii')]:
        try:
            decrypt_text(bad, key, iv)
        except ValueError:
            pass
        else:
            raise AssertionError('Dữ liệu không hợp lệ phải bị từ chối.')
    print('SELF-TEST OK')
if __name__ == '__main__':
    if '--self-test' in sys.argv:
        self_test()
    else:
        App().mainloop()
