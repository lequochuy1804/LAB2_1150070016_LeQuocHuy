package Tuan2.Dulieu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
public final class LichSu {
    private LichSu() {
    }
    public static void insert(String algorithm, String operation, String user, int inputLength, int outputLength)
            throws SQLException {
        if (!java.util.Set.of("REGISTER", "LOGIN", "ENCRYPT", "DECRYPT").contains(operation)
                || inputLength < 0 || outputLength < 0) throw new IllegalArgumentException("Lịch sử không hợp lệ.");
        String sql = "INSERT INTO dbo.crypto_history(algorithm, operation, app_username, input_length, output_length) "
                + "VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = KetNoi.moKetNoi(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setNString(1, algorithm);
            statement.setString(2, operation);
            statement.setNString(3, user);
            statement.setInt(4, inputLength);
            statement.setInt(5, outputLength);
            statement.executeUpdate();
        }
    }
    public static String tryInsert(String algorithm, String operation, int inputLength, int outputLength) {
        return tryInsert(algorithm, operation, null, inputLength, outputLength);
    }
    public static String tryInsert(String algorithm, String operation, String user, int inputLength, int outputLength) {
        if (!KetNoi.daKetNoi()) return "(Chưa kết nối SQL Server - chưa lưu lịch sử)";
        try {
            insert(algorithm, operation, user, inputLength, outputLength);
            return "(Đã lưu lịch sử SQL Server)";
        } catch (SQLException ex) {
            return "(Không lưu được lịch sử SQL Server)";
        }
    }
    public static DefaultTableModel emptyModel() {
        return new DefaultTableModel(new Object[]{"ID", "Thời gian", "Thuật toán", "Thao tác", "User", "Độ dài vào", "Độ dài ra"}, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }
    public static DefaultTableModel loadLatest(int top) throws SQLException {
        if (top < 1 || top > 1000) throw new IllegalArgumentException("Số dòng phải từ 1 đến 1000.");
        var model = emptyModel();
        String sql = "SELECT TOP (?) history_id, created_at, algorithm, operation, app_username, input_length, output_length "
                + "FROM dbo.crypto_history ORDER BY history_id DESC";
        try (Connection connection = KetNoi.moKetNoi(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, top);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) model.addRow(new Object[]{rs.getLong(1), rs.getTimestamp(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), rs.getInt(6), rs.getInt(7)});
            }
        }
        return model;
    }
}
