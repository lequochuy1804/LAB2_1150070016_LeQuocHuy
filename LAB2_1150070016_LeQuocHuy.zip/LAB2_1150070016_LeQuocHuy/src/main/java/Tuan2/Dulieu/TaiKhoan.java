package Tuan2.Dulieu;
import Tuan2.giaodien.CipherUtil;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
public final class TaiKhoan {
    private static final int ITERATIONS = 120_000;
    private TaiKhoan() {
    }
    public static void register(String username, char[] password) throws SQLException {
        if (username == null || !username.matches("[A-Za-z0-9_.]{3,40}")) {
            throw new IllegalArgumentException("Username 3-40 ký tự, chỉ gồm chữ, số, dấu _ hoặc dấu chấm.");
        }
        if (password == null || password.length < 8) throw new IllegalArgumentException("Mật khẩu phải có ít nhất 8 ký tự.");
        byte[] salt = CipherUtil.randomBytes(16);
        byte[] hash = CipherUtil.pbkdf2(password, salt, ITERATIONS, 256);
        try (Connection connection = KetNoi.moKetNoi();
                PreparedStatement statement = connection.prepareStatement("INSERT INTO dbo.app_users(username, salt, password_hash) VALUES (?, ?, ?)")) {
            statement.setNString(1, username);
            statement.setBytes(2, salt);
            statement.setBytes(3, hash);
            statement.executeUpdate();
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 2627 || ex.getErrorCode() == 2601) throw new IllegalArgumentException("Username đã tồn tại.");
            throw ex;
        } finally {
            Arrays.fill(hash, (byte)0);
        }
    }
    public static boolean login(String username, char[] password) throws SQLException {
        if (username == null || password == null) return false;
        try (Connection connection = KetNoi.moKetNoi();
                PreparedStatement statement = connection.prepareStatement("SELECT salt, password_hash FROM dbo.app_users WHERE username = ?")) {
            statement.setNString(1, username);
            try (ResultSet rs = statement.executeQuery()) {
                if (!rs.next()) return false;
                byte[] hash = CipherUtil.pbkdf2(password, rs.getBytes(1), ITERATIONS, 256);
                try {
                    return MessageDigest.isEqual(rs.getBytes(2), hash);
                } finally {
                    Arrays.fill(hash, (byte)0);
                }
            }
        }
    }
    public static String newTicket() {
        return CipherUtil.hex(CipherUtil.randomBytes(16));
    }
}
