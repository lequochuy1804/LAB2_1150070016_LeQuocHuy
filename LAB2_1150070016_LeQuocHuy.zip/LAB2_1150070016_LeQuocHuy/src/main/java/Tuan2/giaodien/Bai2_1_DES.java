package Tuan2.giaodien;
public class Bai2_1_DES extends javax.swing.JFrame {
    public Bai2_1_DES() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints grid;
        setDefaultCloseOperation(2);
        setTitle("DES Cipher");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("MẬT MÃ DES");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setPreferredSize(new java.awt.Dimension(570, 34));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 2;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(20, 20, 6, 20);
        panel_main.add(lbl_title, grid);
        lbl_plaintext = new javax.swing.JLabel();
        lbl_plaintext.setText("Plaintext:");
        lbl_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_plaintext.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_plaintext, grid);
        scroll_plaintext = new javax.swing.JScrollPane();
        scroll_plaintext.setPreferredSize(new java.awt.Dimension(570, 70));
        txt_plaintext = new javax.swing.JTextArea();
        txt_plaintext.setColumns(40);
        txt_plaintext.setRows(3);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_plaintext.setViewportView(txt_plaintext);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 1;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(scroll_plaintext, grid);
        lbl_key = new javax.swing.JLabel();
        lbl_key.setText("Key:");
        lbl_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_key.setPreferredSize(new java.awt.Dimension(96, 24));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_key, grid);
        panel_key = new javax.swing.JPanel();
        panel_key.setBackground(new java.awt.Color(214, 217, 223));
        panel_key.setLayout(new java.awt.GridBagLayout());
        txt_key = new javax.swing.JTextField();
        txt_key.setText("12345678");
        txt_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_key.setPreferredSize(new java.awt.Dimension(300, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_key.add(txt_key, grid);
        lbl_hint = new javax.swing.JLabel();
        lbl_hint.setText("Đúng 8 ký tự không dấu (8 byte)");
        lbl_hint.setFont(new java.awt.Font("Segoe UI", 0, 12));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_key.add(lbl_hint, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_key, grid);
        lbl_ciphertext = new javax.swing.JLabel();
        lbl_ciphertext.setText("Ciphertext:");
        lbl_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_ciphertext, grid);
        scroll_ciphertext = new javax.swing.JScrollPane();
        scroll_ciphertext.setPreferredSize(new java.awt.Dimension(570, 70));
        txt_ciphertext = new javax.swing.JTextArea();
        txt_ciphertext.setColumns(40);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_ciphertext.setViewportView(txt_ciphertext);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 1;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_ciphertext, grid);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_encrypt = new javax.swing.JButton();
        btn_encrypt.setText("Encrypt");
        btn_encrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_encrypt.setPreferredSize(new java.awt.Dimension(100, 30));
        btn_encrypt.addActionListener(evt -> btn_encryptActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_encrypt, grid);
        btn_decrypt = new javax.swing.JButton();
        btn_decrypt.setText("Decrypt");
        btn_decrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_decrypt.setPreferredSize(new java.awt.Dimension(100, 30));
        btn_decrypt.addActionListener(evt -> btn_decryptActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_decrypt, grid);
        btn_open = new javax.swing.JButton();
        btn_open.setText("Open File");
        btn_open.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_open.setPreferredSize(new java.awt.Dimension(120, 30));
        btn_open.addActionListener(evt -> btn_openActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 3;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_open, grid);
        btn_save = new javax.swing.JButton();
        btn_save.setText("Save File");
        btn_save.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_save.setPreferredSize(new java.awt.Dimension(120, 30));
        btn_save.addActionListener(evt -> btn_saveActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_save, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_actions, grid);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Sẵn sàng.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(566, 36));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(lbl_status, grid);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        xuLy(true);
    }
    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        xuLy(false);
    }
    private void xuLy(boolean maHoa) {
        String input = maHoa ? txt_plaintext.getText() : txt_ciphertext.getText();
        if (input.isEmpty()) {
            showError(maHoa ? "Hãy nhập Plaintext trước khi mã hóa." : "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        String key = txt_key.getText();
        btn_encrypt.setEnabled(false);
        btn_decrypt.setEnabled(false);
        lbl_status.setText("Đang xử lý...");
        new javax.swing.SwingWorker<String[], Void>() {
            protected String[] doInBackground() throws Exception {
                String output = maHoa ? encrypt(input, key) : decrypt(input, key);
                String status = Tuan2.Dulieu.LichSu.tryInsert("DES", maHoa ? "ENCRYPT" : "DECRYPT",
                        input.length(), output.length());
                return new String[]{output, status};
            }
            protected void done() {
                try {
                    String[] result = get();
                    if (maHoa) txt_ciphertext.setText(result[0]);
                    else txt_plaintext.setText(result[0]);
                    lbl_status.setText("<html>Đã " + (maHoa ? "mã hóa" : "giải mã") + " DES. " + result[1] + "</html>");
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    showError("Thao tác đã bị gián đoạn.");
                } catch (java.util.concurrent.ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    showError(cause instanceof IllegalArgumentException ? cause.getMessage()
                            : "Xử lý thất bại: sai Key hoặc bản mã bị hỏng.");
                } finally {
                    btn_encrypt.setEnabled(true);
                    btn_decrypt.setEnabled(true);
                }
            }
        }.execute();
    }
    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) lbl_status.setText("Đã mở tệp: " + path);
    }
    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.saveText(this, txt_ciphertext, "des_ciphertext.txt");
        if (path != null) lbl_status.setText("Đã lưu tệp: " + path);
    }
    private void showError(String message) {
        lbl_status.setText(message);
        javax.swing.JOptionPane.showMessageDialog(this, message, "Dữ liệu không hợp lệ",
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            java.awt.Toolkit.getDefaultToolkit().beep();
        }
        java.awt.EventQueue.invokeLater(() -> new Bai2_1_DES().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_plaintext;
    private javax.swing.JScrollPane scroll_plaintext;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JLabel lbl_key;
    private javax.swing.JPanel panel_key;
    private javax.swing.JTextField txt_key;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JLabel lbl_ciphertext;
    private javax.swing.JScrollPane scroll_ciphertext;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_open;
    private javax.swing.JButton btn_save;
    private javax.swing.JLabel lbl_status;
    private static final java.security.SecureRandom RANDOM = new java.security.SecureRandom();
    private static javax.crypto.spec.SecretKeySpec key(String value) {
        if (value == null || value.isEmpty()) throw new IllegalArgumentException("Hãy nhập Key.");
        byte[] bytes = value.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        if (bytes.length != 8) {
            throw new IllegalArgumentException("Khóa DES phải đúng 8 byte (gõ 8 ký tự không dấu). Hiện có "
                    + bytes.length + " byte.");
        }
        return new javax.crypto.spec.SecretKeySpec(bytes, "DES");
    }
    public static String encrypt(String plaintext, String password) throws java.security.GeneralSecurityException {
        javax.crypto.spec.SecretKeySpec secret = key(password);
        byte[] iv = new byte[8];
        RANDOM.nextBytes(iv);
        javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("DES/CBC/PKCS5Padding");
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, secret, new javax.crypto.spec.IvParameterSpec(iv));
        byte[] encrypted = cipher.doFinal(plaintext.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        byte[] result = java.util.Arrays.copyOf(iv, iv.length + encrypted.length);
        System.arraycopy(encrypted, 0, result, iv.length, encrypted.length);
        return java.util.Base64.getEncoder().encodeToString(result);
    }
    public static String decrypt(String ciphertext, String password) throws java.security.GeneralSecurityException {
        javax.crypto.spec.SecretKeySpec secret = key(password);
        byte[] all;
        try {
            all = java.util.Base64.getDecoder().decode(ciphertext.trim());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Dữ liệu không phải Base64 hợp lệ.");
        }
        if (all.length < 16 || (all.length - 8) % 8 != 0) {
            throw new IllegalArgumentException("Bản mã quá ngắn hoặc bị hỏng.");
        }
        byte[] iv = java.util.Arrays.copyOfRange(all, 0, 8);
        javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("DES/CBC/PKCS5Padding");
        cipher.init(javax.crypto.Cipher.DECRYPT_MODE, secret, new javax.crypto.spec.IvParameterSpec(iv));
        byte[] plain = cipher.doFinal(all, 8, all.length - 8);
        try {
            return java.nio.charset.StandardCharsets.UTF_8.newDecoder()
                    .decode(java.nio.ByteBuffer.wrap(plain)).toString();
        } catch (java.nio.charset.CharacterCodingException ex) {
            throw new java.security.GeneralSecurityException("Bản rõ không phải UTF-8 hợp lệ.", ex);
        }
    }
}
