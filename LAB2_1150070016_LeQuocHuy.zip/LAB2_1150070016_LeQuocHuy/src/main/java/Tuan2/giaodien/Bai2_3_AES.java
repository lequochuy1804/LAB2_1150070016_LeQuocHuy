package Tuan2.giaodien;
public class Bai2_3_AES extends javax.swing.JFrame {
    public Bai2_3_AES() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints grid;
        setDefaultCloseOperation(2);
        setTitle("AES Cipher - Register / Login");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("AES-GCM - ĐĂNG KÝ / ĐĂNG NHẬP (SQL SERVER)");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setPreferredSize(new java.awt.Dimension(678, 34));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 2;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(20, 20, 6, 20);
        panel_main.add(lbl_title, grid);
        lbl_1 = new javax.swing.JLabel();
        lbl_1.setText("Username:");
        lbl_1.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_1.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_1, grid);
        panel_username = new javax.swing.JPanel();
        panel_username.setBackground(new java.awt.Color(214, 217, 223));
        panel_username.setLayout(new java.awt.GridBagLayout());
        txt_username = new javax.swing.JTextField();
        txt_username.setText("sinhvien01");
        txt_username.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_username.setPreferredSize(new java.awt.Dimension(250, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_username.add(txt_username, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_username, grid);
        lbl_2 = new javax.swing.JLabel();
        lbl_2.setText("Password:");
        lbl_2.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_2.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_2, grid);
        panel_password = new javax.swing.JPanel();
        panel_password.setBackground(new java.awt.Color(214, 217, 223));
        panel_password.setLayout(new java.awt.GridBagLayout());
        txt_password = new javax.swing.JPasswordField();
        txt_password.setText("");
        txt_password.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_password.setPreferredSize(new java.awt.Dimension(250, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_password.add(txt_password, grid);
        lbl_passhint = new javax.swing.JLabel();
        lbl_passhint.setText("(ít nhất 8 ký tự)");
        lbl_passhint.setFont(new java.awt.Font("Segoe UI", 0, 12));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_password.add(lbl_passhint, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_password, grid);
        lbl_3 = new javax.swing.JLabel();
        lbl_3.setText("");
        lbl_3.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_3.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_3, grid);
        panel_account = new javax.swing.JPanel();
        panel_account.setBackground(new java.awt.Color(214, 217, 223));
        panel_account.setLayout(new java.awt.GridBagLayout());
        btn_sql = new javax.swing.JButton();
        btn_sql.setText("Kết nối SQL Server");
        btn_sql.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_sql.setPreferredSize(new java.awt.Dimension(170, 30));
        btn_sql.addActionListener(evt -> btn_sqlActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_account.add(btn_sql, grid);
        btn_register = new javax.swing.JButton();
        btn_register.setText("Register");
        btn_register.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_register.setPreferredSize(new java.awt.Dimension(110, 30));
        btn_register.addActionListener(evt -> btn_registerActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_account.add(btn_register, grid);
        btn_login = new javax.swing.JButton();
        btn_login.setText("Login");
        btn_login.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_login.setPreferredSize(new java.awt.Dimension(110, 30));
        btn_login.addActionListener(evt -> btn_loginActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_account.add(btn_login, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_account, grid);
        lbl_4 = new javax.swing.JLabel();
        lbl_4.setText("Ticket:");
        lbl_4.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_4.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 16, 14);
        panel_main.add(lbl_4, grid);
        panel_ticket = new javax.swing.JPanel();
        panel_ticket.setBackground(new java.awt.Color(214, 217, 223));
        panel_ticket.setLayout(new java.awt.GridBagLayout());
        txt_ticket = new javax.swing.JTextField();
        txt_ticket.setText("");
        txt_ticket.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_ticket.setPreferredSize(new java.awt.Dimension(420, 28));
        txt_ticket.setEditable(false);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_ticket.add(txt_ticket, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 16, 20);
        panel_main.add(panel_ticket, grid);
        lbl_5 = new javax.swing.JLabel();
        lbl_5.setText("Plaintext:");
        lbl_5.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_5.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_5, grid);
        scroll_txt_plaintext = new javax.swing.JScrollPane();
        scroll_txt_plaintext.setPreferredSize(new java.awt.Dimension(570, 70));
        txt_plaintext = new javax.swing.JTextArea();
        txt_plaintext.setColumns(40);
        txt_plaintext.setRows(3);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_plaintext.setViewportView(txt_plaintext);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(scroll_txt_plaintext, grid);
        lbl_6 = new javax.swing.JLabel();
        lbl_6.setText("Key AES:");
        lbl_6.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_6.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 6;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_6, grid);
        panel_key = new javax.swing.JPanel();
        panel_key.setBackground(new java.awt.Color(214, 217, 223));
        panel_key.setLayout(new java.awt.GridBagLayout());
        txt_key = new javax.swing.JTextField();
        txt_key.setText("");
        txt_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_key.setPreferredSize(new java.awt.Dimension(300, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_key.add(txt_key, grid);
        lbl_hint = new javax.swing.JLabel();
        lbl_hint.setText("Mật khẩu để tạo khóa AES-256");
        lbl_hint.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_hint.setPreferredSize(new java.awt.Dimension(256, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_key.add(lbl_hint, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 6;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_key, grid);
        lbl_7 = new javax.swing.JLabel();
        lbl_7.setText("Ciphertext:");
        lbl_7.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_7.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 7;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_7, grid);
        scroll_txt_ciphertext = new javax.swing.JScrollPane();
        scroll_txt_ciphertext.setPreferredSize(new java.awt.Dimension(570, 70));
        txt_ciphertext = new javax.swing.JTextArea();
        txt_ciphertext.setColumns(40);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_ciphertext.setViewportView(txt_ciphertext);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 7;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_txt_ciphertext, grid);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_encrypt = new javax.swing.JButton();
        btn_encrypt.setText("Encrypt");
        btn_encrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_encrypt.setPreferredSize(new java.awt.Dimension(100, 30));
        btn_encrypt.addActionListener(evt -> btn_encryptActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_encrypt, grid);
        btn_decrypt = new javax.swing.JButton();
        btn_decrypt.setText("Decrypt");
        btn_decrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_decrypt.setPreferredSize(new java.awt.Dimension(100, 30));
        btn_decrypt.addActionListener(evt -> btn_decryptActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_decrypt, grid);
        btn_save = new javax.swing.JButton();
        btn_save.setText("Save File");
        btn_save.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_save.setPreferredSize(new java.awt.Dimension(120, 30));
        btn_save.addActionListener(evt -> btn_saveActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_save, grid);
        btn_open = new javax.swing.JButton();
        btn_open.setText("Open File");
        btn_open.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_open.setPreferredSize(new java.awt.Dimension(120, 30));
        btn_open.addActionListener(evt -> btn_openActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 3;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_open, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 8;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_actions, grid);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Sẵn sàng.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(566, 36));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 9;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(lbl_status, grid);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }
    private void btn_registerActionPerformed(java.awt.event.ActionEvent evt) {
        String user = txt_username.getText().trim();
        char[] password = txt_password.getPassword();
        runAsync(() -> {
            try {
                Tuan2.Dulieu.TaiKhoan.register(user, password);
                return Tuan2.Dulieu.LichSu.tryInsert("AES", "REGISTER", user, 0, 0);
            } finally {
                java.util.Arrays.fill(password, '\0');
            }
        }, result -> lbl_status.setText("<html>Register thành công: " + user + ". Bấm Login để đăng nhập. " + result + "</html>"));
    }
    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {
        currentUser = null;
        txt_ticket.setText("");
        String user = txt_username.getText().trim();
        char[] password = txt_password.getPassword();
        runAsync(() -> {
            try {
                if (!Tuan2.Dulieu.TaiKhoan.login(user, password)) throw new IllegalArgumentException("Sai username hoặc mật khẩu.");
                return new String[]{Tuan2.Dulieu.TaiKhoan.newTicket(), Tuan2.Dulieu.LichSu.tryInsert("AES", "LOGIN", user, 0, 0)};
            } finally {
                java.util.Arrays.fill(password, '\0');
            }
        }, result -> {
            currentUser = user;
            txt_ticket.setText(result[0]);
            txt_password.setText("");
            lbl_status.setText("<html>Login thành công: " + user + ". Có thể dùng Encrypt/Decrypt. " + result[1] + "</html>");
        });
    }
    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        xuLy(true);
    }
    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        xuLy(false);
    }
    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.saveText(this, txt_ciphertext, "aes_ciphertext.txt");
        if (path != null) lbl_status.setText("Đã lưu tệp: " + path);
    }
    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) lbl_status.setText("Đã mở tệp: " + path);
    }
    private boolean processing;
    private void showError(String message) {
        lbl_status.setText("<html>" + message + "</html>");
        javax.swing.JOptionPane.showMessageDialog(this, message, "Thông báo", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    private void enableInputs(java.awt.Container container, boolean enabled) {
        for (java.awt.Component component : container.getComponents()) {
            if (component instanceof javax.swing.JButton || component instanceof javax.swing.text.JTextComponent) component.setEnabled(enabled);
            if (component instanceof java.awt.Container child) enableInputs(child, enabled);
        }
    }
    private <T> void runAsync(java.util.concurrent.Callable<T> work, java.util.function.Consumer<T> complete) {
        if (processing) return;
        processing = true;
        enableInputs(panel_main, false);
        lbl_status.setText("Đang xử lý...");
        new javax.swing.SwingWorker<T, Void>() {
            protected T doInBackground() throws Exception {
                return work.call();
            }
            protected void done() {
                try {
                    complete.accept(get());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    showError("Thao tác đã bị gián đoạn.");
                } catch (java.util.concurrent.ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    if (cause instanceof javax.crypto.AEADBadTagException) showError("Giải mã thất bại: sai Key hoặc bản mã bị sửa.");
                    else if (cause instanceof java.sql.SQLException) showError("Không thực hiện được thao tác SQL Server. Kiểm tra kết nối và quyền truy cập.");
                    else if (cause instanceof IllegalArgumentException) showError(cause.getMessage());
                    else showError("Xử lý thất bại: sai Key, IV hoặc dữ liệu bị hỏng.");
                } finally {
                    processing = false;
                    enableInputs(panel_main, true);
                }
            }
        }.execute();
    }
    private String currentUser;
    public static String encrypt(String plaintext, String password) throws Exception {
        CipherUtil.requireKey(password);
        byte[] salt = CipherUtil.randomBytes(16);
        byte[] nonce = CipherUtil.randomBytes(12);
        char[] chars = password.toCharArray();
        byte[] key = CipherUtil.pbkdf2(chars, salt, 120_000, 256);
        java.util.Arrays.fill(chars, '\0');
        try {
            var cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, new javax.crypto.spec.SecretKeySpec(key, "AES"),
                    new javax.crypto.spec.GCMParameterSpec(128, nonce));
            return CipherUtil.b64(CipherUtil.concat(CipherUtil.concat(salt, nonce), cipher.doFinal(CipherUtil.utf8(plaintext))));
        } finally {
            java.util.Arrays.fill(key, (byte)0);
        }
    }
    public static String decrypt(String ciphertext, String password) throws Exception {
        CipherUtil.requireKey(password);
        byte[] all = CipherUtil.fromB64(ciphertext);
        if (all.length < 44) throw new IllegalArgumentException("Bản mã AES quá ngắn hoặc bị hỏng.");
        byte[] salt = java.util.Arrays.copyOfRange(all, 0, 16);
        byte[] nonce = java.util.Arrays.copyOfRange(all, 16, 28);
        char[] chars = password.toCharArray();
        byte[] key = CipherUtil.pbkdf2(chars, salt, 120_000, 256);
        java.util.Arrays.fill(chars, '\0');
        try {
            var cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, new javax.crypto.spec.SecretKeySpec(key, "AES"),
                    new javax.crypto.spec.GCMParameterSpec(128, nonce));
            return CipherUtil.text(cipher.doFinal(all, 28, all.length - 28));
        } finally {
            java.util.Arrays.fill(key, (byte)0);
        }
    }
    private void xuLy(boolean encrypting) {
        if (currentUser == null || txt_ticket.getText().isEmpty()) {
            showError("Hãy Login trước khi dùng AES.");
            return;
        }
        String input = encrypting ? txt_plaintext.getText() : txt_ciphertext.getText();
        if (input.isEmpty()) {
            showError(encrypting ? "Hãy nhập Plaintext trước khi mã hóa." : "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        String key = txt_key.getText();
        String user = currentUser;
        runAsync(() -> {
            String output = encrypting ? encrypt(input, key) : decrypt(input, key);
            String history = Tuan2.Dulieu.LichSu.tryInsert("AES", encrypting ? "ENCRYPT" : "DECRYPT", user, input.length(), output.length());
            return new String[]{output, history};
        }, result -> {
            if (encrypting) txt_ciphertext.setText(result[0]);
            else txt_plaintext.setText(result[0]);
            lbl_status.setText("<html>Đã " + (encrypting ? "mã hóa" : "giải mã") + " AES. " + result[1] + "</html>");
        });
    }
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            java.awt.Toolkit.getDefaultToolkit().beep();
        }
        java.awt.EventQueue.invokeLater(() -> new Bai2_3_AES().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_1;
    private javax.swing.JPanel panel_username;
    private javax.swing.JTextField txt_username;
    private javax.swing.JLabel lbl_2;
    private javax.swing.JPanel panel_password;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JLabel lbl_passhint;
    private javax.swing.JLabel lbl_3;
    private javax.swing.JPanel panel_account;
    private javax.swing.JButton btn_sql;
    private javax.swing.JButton btn_register;
    private javax.swing.JButton btn_login;
    private javax.swing.JLabel lbl_4;
    private javax.swing.JPanel panel_ticket;
    private javax.swing.JTextField txt_ticket;
    private javax.swing.JLabel lbl_5;
    private javax.swing.JScrollPane scroll_txt_plaintext;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JLabel lbl_6;
    private javax.swing.JPanel panel_key;
    private javax.swing.JTextField txt_key;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JLabel lbl_7;
    private javax.swing.JScrollPane scroll_txt_ciphertext;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_open;
    private javax.swing.JLabel lbl_status;
}
