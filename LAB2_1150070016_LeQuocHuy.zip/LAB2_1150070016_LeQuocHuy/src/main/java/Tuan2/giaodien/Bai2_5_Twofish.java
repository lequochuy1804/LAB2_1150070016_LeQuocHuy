package Tuan2.giaodien;
public class Bai2_5_Twofish extends javax.swing.JFrame {
    public Bai2_5_Twofish() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints grid;
        setDefaultCloseOperation(2);
        setTitle("Twofish Cipher");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("MẬT MÃ TWOFISH (CBC)");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setPreferredSize(new java.awt.Dimension(678, 34));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 2;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(20, 20, 6, 20);
        panel_main.add(lbl_title, grid);
        lbl_1 = new javax.swing.JLabel();
        lbl_1.setText("Plaintext:");
        lbl_1.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_1.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_1, grid);
        scroll_txt_plaintext = new javax.swing.JScrollPane();
        scroll_txt_plaintext.setPreferredSize(new java.awt.Dimension(570, 70));
        txt_plaintext = new javax.swing.JTextArea();
        txt_plaintext.setColumns(40);
        txt_plaintext.setRows(3);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_plaintext.setViewportView(txt_plaintext);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(scroll_txt_plaintext, grid);
        lbl_2 = new javax.swing.JLabel();
        lbl_2.setText("Key:");
        lbl_2.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_2.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_2, grid);
        panel_key = new javax.swing.JPanel();
        panel_key.setBackground(new java.awt.Color(214, 217, 223));
        panel_key.setLayout(new java.awt.GridBagLayout());
        txt_key = new javax.swing.JTextField();
        txt_key.setText("Twofish@Lab2");
        txt_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_key.setPreferredSize(new java.awt.Dimension(300, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_key.add(txt_key, grid);
        lbl_hint = new javax.swing.JLabel();
        lbl_hint.setText("Mật khẩu bất kỳ (khóa = SHA-256)");
        lbl_hint.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_hint.setPreferredSize(new java.awt.Dimension(256, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_key.add(lbl_hint, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_key, grid);
        lbl_3 = new javax.swing.JLabel();
        lbl_3.setText("IV (HEX):");
        lbl_3.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_3.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_3, grid);
        panel_iv = new javax.swing.JPanel();
        panel_iv.setBackground(new java.awt.Color(214, 217, 223));
        panel_iv.setLayout(new java.awt.GridBagLayout());
        txt_iv = new javax.swing.JTextField();
        txt_iv.setText("");
        txt_iv.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_iv.setPreferredSize(new java.awt.Dimension(330, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_iv.add(txt_iv, grid);
        btn_iv = new javax.swing.JButton();
        btn_iv.setText("Generate IV");
        btn_iv.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_iv.setPreferredSize(new java.awt.Dimension(130, 30));
        btn_iv.addActionListener(evt -> btn_ivActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_iv.add(btn_iv, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_iv, grid);
        lbl_4 = new javax.swing.JLabel();
        lbl_4.setText("Ciphertext:");
        lbl_4.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_4.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_4, grid);
        scroll_txt_ciphertext = new javax.swing.JScrollPane();
        scroll_txt_ciphertext.setPreferredSize(new java.awt.Dimension(570, 70));
        txt_ciphertext = new javax.swing.JTextArea();
        txt_ciphertext.setColumns(40);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_ciphertext.setViewportView(txt_ciphertext);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_txt_ciphertext, grid);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_encrypt = new javax.swing.JButton();
        btn_encrypt.setText("Encrypt");
        btn_encrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_encrypt.setPreferredSize(new java.awt.Dimension(100, 30));
        btn_encrypt.addActionListener(evt -> btn_encryptActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_encrypt, grid);
        btn_decrypt = new javax.swing.JButton();
        btn_decrypt.setText("Decrypt");
        btn_decrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_decrypt.setPreferredSize(new java.awt.Dimension(100, 30));
        btn_decrypt.addActionListener(evt -> btn_decryptActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_decrypt, grid);
        btn_save = new javax.swing.JButton();
        btn_save.setText("Save File");
        btn_save.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_save.setPreferredSize(new java.awt.Dimension(120, 30));
        btn_save.addActionListener(evt -> btn_saveActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_save, grid);
        btn_open = new javax.swing.JButton();
        btn_open.setText("Open File");
        btn_open.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_open.setPreferredSize(new java.awt.Dimension(120, 30));
        btn_open.addActionListener(evt -> btn_openActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 3;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_open, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_actions, grid);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Sẵn sàng.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(566, 36));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 6;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(lbl_status, grid);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_ivActionPerformed(java.awt.event.ActionEvent evt) {
        txt_iv.setText(newIv());
        lbl_status.setText("Đã tạo IV ngẫu nhiên 16 byte. Giữ nguyên IV này để giải mã.");
    }
    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        xuLy(true);
    }
    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        xuLy(false);
    }
    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            if (txt_ciphertext.getText().isEmpty()) throw new IllegalArgumentException("Chưa có bản mã để lưu.");
            String content = toFile(txt_iv.getText(), txt_ciphertext.getText());
            String path = FileTextIO.saveString(this, content, "twofish_ciphertext.txt");
            if (path != null) lbl_status.setText("Đã lưu tệp: " + path);
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }
    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {
        String content = FileTextIO.openString(this);
        if (content == null) return;
        try {
            String[] parts = fromFile(content);
            txt_iv.setText(parts[0]);
            txt_ciphertext.setText(parts[1]);
            lbl_status.setText("Đã khôi phục tham số và bản mã. Nhập đúng Key rồi bấm Decrypt.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }
    private boolean processing;
    private void showError(String message) {
        lbl_status.setText("<html>" + message + "</html>");
        javax.swing.JOptionPane.showMessageDialog(this, message, "Thông báo", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    private void enableInputs(java.awt.Container container, boolean enabled) {
        for (java.awt.Component component : container.getComponents()) {
            if (component instanceof javax.swing.JButton || component instanceof javax.swing.text.JTextComponent) component.setEnabled(enabled);
            if (component instanceof java.awt.Container child) enableInputs(child, enabled);
        }
    }
    private <T> void runAsync(java.util.concurrent.Callable<T> work, java.util.function.Consumer<T> complete) {
        if (processing) return;
        processing = true;
        enableInputs(panel_main, false);
        lbl_status.setText("Đang xử lý...");
        new javax.swing.SwingWorker<T, Void>() {
            protected T doInBackground() throws Exception {
                return work.call();
            }
            protected void done() {
                try {
                    complete.accept(get());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    showError("Thao tác đã bị gián đoạn.");
                } catch (java.util.concurrent.ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    if (cause instanceof javax.crypto.AEADBadTagException) showError("Giải mã thất bại: sai Key hoặc bản mã bị sửa.");
                    else if (cause instanceof java.sql.SQLException) showError("Không thực hiện được thao tác SQL Server. Kiểm tra kết nối và quyền truy cập.");
                    else if (cause instanceof IllegalArgumentException) showError(cause.getMessage());
                    else showError("Xử lý thất bại: sai Key, IV hoặc dữ liệu bị hỏng.");
                } finally {
                    processing = false;
                    enableInputs(panel_main, true);
                }
            }
        }.execute();
    }
    public static String newIv() {
        return CipherUtil.hex(CipherUtil.randomBytes(16));
    }
    private static byte[] crypt(boolean encrypt, byte[] input, String password, String ivHex) throws Exception {
        CipherUtil.requireKey(password);
        byte[] iv = CipherUtil.fromHex(ivHex);
        if (iv.length != 16) throw new IllegalArgumentException("IV phải đúng 16 byte = 32 ký tự HEX. Bấm Generate IV.");
        byte[] key = java.security.MessageDigest.getInstance("SHA-256").digest(CipherUtil.utf8(password));
        try {
            var cipher = new org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher(
                    org.bouncycastle.crypto.modes.CBCBlockCipher.newInstance(new org.bouncycastle.crypto.engines.TwofishEngine()));
            cipher.init(encrypt, new org.bouncycastle.crypto.params.ParametersWithIV(
                    new org.bouncycastle.crypto.params.KeyParameter(key), iv));
            byte[] output = new byte[cipher.getOutputSize(input.length)];
            int length = cipher.processBytes(input, 0, input.length, output, 0);
            length += cipher.doFinal(output, length);
            return java.util.Arrays.copyOf(output, length);
        } finally {
            java.util.Arrays.fill(key, (byte)0);
        }
    }
    public static String encrypt(String text, String key, String iv) throws Exception {
        return CipherUtil.b64(crypt(true, CipherUtil.utf8(text), key, iv));
    }
    public static String decrypt(String text, String key, String iv) throws Exception {
        byte[] data = CipherUtil.fromB64(text);
        if (data.length == 0 || data.length % 16 != 0) throw new IllegalArgumentException("Bản mã Twofish phải là bội số của 16 byte.");
        return CipherUtil.text(crypt(false, data, key, iv));
    }
    public static String toFile(String iv, String ciphertext) {
        if (CipherUtil.fromHex(iv).length != 16) throw new IllegalArgumentException("IV phải có 32 ký tự HEX.");
        byte[] data = CipherUtil.fromB64(ciphertext);
        if (data.length == 0 || data.length % 16 != 0) throw new IllegalArgumentException("Bản mã Twofish không hợp lệ.");
        return "IV=" + iv.trim() + "\n" + ciphertext.trim() + "\n";
    }
    public static String[] fromFile(String content) {
        String[] parts = CipherUtil.fromFile(content, "IV=");
        toFile(parts[0], parts[1]);
        return parts;
    }
    private void xuLy(boolean encrypting) {
        String input = encrypting ? txt_plaintext.getText() : txt_ciphertext.getText();
        if (input.isEmpty()) {
            showError(encrypting ? "Hãy nhập Plaintext trước khi mã hóa." : "Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        String key = txt_key.getText();
        String parameter = txt_iv.getText();
        String user = null;
        runAsync(() -> {
            String output = encrypting ? encrypt(input, key, parameter) : decrypt(input, key, parameter);
            String history = Tuan2.Dulieu.LichSu.tryInsert("Twofish", encrypting ? "ENCRYPT" : "DECRYPT", user, input.length(), output.length());
            return new String[]{output, history};
        }, result -> {
            if (encrypting) txt_ciphertext.setText(result[0]);
            else txt_plaintext.setText(result[0]);
            lbl_status.setText("<html>Đã " + (encrypting ? "mã hóa" : "giải mã") + " Twofish. " + result[1] + "</html>");
        });
    }
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            java.awt.Toolkit.getDefaultToolkit().beep();
        }
        java.awt.EventQueue.invokeLater(() -> new Bai2_5_Twofish().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_1;
    private javax.swing.JScrollPane scroll_txt_plaintext;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JLabel lbl_2;
    private javax.swing.JPanel panel_key;
    private javax.swing.JTextField txt_key;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JLabel lbl_3;
    private javax.swing.JPanel panel_iv;
    private javax.swing.JTextField txt_iv;
    private javax.swing.JButton btn_iv;
    private javax.swing.JLabel lbl_4;
    private javax.swing.JScrollPane scroll_txt_ciphertext;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_save;
    private javax.swing.JButton btn_open;
    private javax.swing.JLabel lbl_status;
}
