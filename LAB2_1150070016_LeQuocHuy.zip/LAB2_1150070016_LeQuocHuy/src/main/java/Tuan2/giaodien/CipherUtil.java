package Tuan2.giaodien;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
public final class CipherUtil {
    private static final SecureRandom RANDOM = new SecureRandom();
    private CipherUtil() {
    }
    public static byte[] utf8(String value) {
        return value.getBytes(StandardCharsets.UTF_8);
    }
    public static String text(byte[] bytes) {
        try {
            return StandardCharsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(bytes)).toString();
        } catch (java.nio.charset.CharacterCodingException ex) {
            throw new IllegalArgumentException("Giải mã thất bại: sai Key hoặc dữ liệu không phải UTF-8.");
        }
    }
    public static String b64(byte[] bytes) {
        return Base64.getEncoder().encodeToString(bytes);
    }
    public static byte[] fromB64(String value) {
        if (value == null) throw new IllegalArgumentException("Chưa có dữ liệu Base64.");
        try {
            return Base64.getDecoder().decode(value.trim());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Dữ liệu không phải Base64 hợp lệ.");
        }
    }
    public static byte[] randomBytes(int count) {
        byte[] bytes = new byte[count];
        RANDOM.nextBytes(bytes);
        return bytes;
    }
    public static String hex(byte[] data) {
        return java.util.HexFormat.of().withUpperCase().formatHex(data);
    }
    public static byte[] fromHex(String value) {
        if (value == null) throw new IllegalArgumentException("Chưa có dữ liệu HEX.");
        try {
            return java.util.HexFormat.of().parseHex(value.trim());
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("HEX chỉ gồm 0-9, A-F và phải có số ký tự chẵn.");
        }
    }
    public static void requireKey(String key) {
        if (key == null || key.isEmpty()) throw new IllegalArgumentException("Hãy nhập Key.");
    }
    public static byte[] concat(byte[] first, byte[] second) {
        byte[] result = java.util.Arrays.copyOf(first, first.length + second.length);
        System.arraycopy(second, 0, result, first.length, second.length);
        return result;
    }
    public static byte[] pbkdf2(char[] password, byte[] salt, int iterations, int bits) {
        PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, bits);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (java.security.GeneralSecurityException ex) {
            throw new IllegalStateException("Không tạo được khóa PBKDF2.", ex);
        } finally {
            spec.clearPassword();
        }
    }
    public static String[] fromFile(String content, String prefix) {
        if (content == null) throw new IllegalArgumentException("Chưa có nội dung tệp.");
        String[] parts = content.strip().split("\\R", 2);
        if (parts.length != 2 || !parts[0].startsWith(prefix)) {
            throw new IllegalArgumentException("Tệp không đúng định dạng: dòng 1 là " + prefix + ", dòng 2 là bản mã.");
        }
        String parameter = parts[0].substring(prefix.length()).trim();
        String cipher = parts[1].trim();
        if (parameter.isEmpty() || cipher.isEmpty()) throw new IllegalArgumentException("Tệp thiếu dữ liệu.");
        return new String[]{parameter, cipher};
    }
}
