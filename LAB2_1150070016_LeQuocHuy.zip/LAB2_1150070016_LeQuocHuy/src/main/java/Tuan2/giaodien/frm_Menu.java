package Tuan2.giaodien;
public class frm_Menu extends javax.swing.JFrame {
    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints grid;
        setDefaultCloseOperation(3);
        setTitle("LAB 2 - Mã hóa đối xứng hiện đại");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("LAB 2 - MÃ HÓA ĐỐI XỨNG HIỆN ĐẠI");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 20));
        lbl_title.setPreferredSize(new java.awt.Dimension(640, 38));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 3;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(20, 20, 8, 20);
        panel_main.add(lbl_title, grid);
        lbl_intro = new javax.swing.JLabel();
        lbl_intro.setText("Chọn một bài để mở form tương ứng:");
        lbl_intro.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_intro.setPreferredSize(new java.awt.Dimension(640, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 1;
        grid.gridwidth = 3;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 20);
        panel_main.add(lbl_intro, grid);
        btn_des = new javax.swing.JButton();
        btn_des.setText("2.1 DES");
        btn_des.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_des.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_des.addActionListener(evt -> btn_desActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 0);
        panel_main.add(btn_des, grid);
        btn_tripledes = new javax.swing.JButton();
        btn_tripledes.setText("2.2 TripleDES");
        btn_tripledes.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_tripledes.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_tripledes.addActionListener(evt -> btn_tripledesActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 12, 0);
        panel_main.add(btn_tripledes, grid);
        btn_aes = new javax.swing.JButton();
        btn_aes.setText("2.3 AES + Login");
        btn_aes.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_aes.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_aes.addActionListener(evt -> btn_aesActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 12, 20);
        panel_main.add(btn_aes, grid);
        btn_rc4 = new javax.swing.JButton();
        btn_rc4.setText("2.4 RC4");
        btn_rc4.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_rc4.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_rc4.addActionListener(evt -> btn_rc4ActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 0);
        panel_main.add(btn_rc4, grid);
        btn_twofish = new javax.swing.JButton();
        btn_twofish.setText("2.5 Twofish");
        btn_twofish.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_twofish.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_twofish.addActionListener(evt -> btn_twofishActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 12, 0);
        panel_main.add(btn_twofish, grid);
        btn_aesctr = new javax.swing.JButton();
        btn_aesctr.setText("2.6 Nâng cao - AES-CTR");
        btn_aesctr.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_aesctr.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_aesctr.addActionListener(evt -> btn_aesctrActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 12, 20);
        panel_main.add(btn_aesctr, grid);
        btn_sql = new javax.swing.JButton();
        btn_sql.setText("Kết nối SQL Server");
        btn_sql.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_sql.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_sql.addActionListener(evt -> btn_sqlActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 18, 0);
        panel_main.add(btn_sql, grid);
        btn_history = new javax.swing.JButton();
        btn_history.setText("Xem lịch sử");
        btn_history.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_history.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_history.addActionListener(evt -> btn_historyActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 18, 0);
        panel_main.add(btn_history, grid);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Bài nâng cao 02 (AES-CBC) viết bằng Python: chạy tệp python/bai2nangcao.py.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(640, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 5;
        grid.gridwidth = 3;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 20);
        panel_main.add(lbl_status, grid);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_desActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai2_1_DES().setVisible(true);
    }
    private void btn_tripledesActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai2_2_TripleDES().setVisible(true);
    }
    private void btn_aesActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai2_3_AES().setVisible(true);
    }
    private void btn_rc4ActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai2_4_RC4().setVisible(true);
    }
    private void btn_twofishActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai2_5_Twofish().setVisible(true);
    }
    private void btn_aesctrActionPerformed(java.awt.event.ActionEvent evt) {
        new bai1nangcao().setVisible(true);
    }
    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }
    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }
    private boolean processing;
    private void showError(String message) {
        lbl_status.setText("<html>" + message + "</html>");
        javax.swing.JOptionPane.showMessageDialog(this, message, "Thông báo", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    private void enableInputs(java.awt.Container container, boolean enabled) {
        for (java.awt.Component component : container.getComponents()) {
            if (component instanceof javax.swing.JButton || component instanceof javax.swing.text.JTextComponent) component.setEnabled(enabled);
            if (component instanceof java.awt.Container child) enableInputs(child, enabled);
        }
    }
    private <T> void runAsync(java.util.concurrent.Callable<T> work, java.util.function.Consumer<T> complete) {
        if (processing) return;
        processing = true;
        enableInputs(panel_main, false);
        lbl_status.setText("Đang xử lý...");
        new javax.swing.SwingWorker<T, Void>() {
            protected T doInBackground() throws Exception {
                return work.call();
            }
            protected void done() {
                try {
                    complete.accept(get());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    showError("Thao tác đã bị gián đoạn.");
                } catch (java.util.concurrent.ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    if (cause instanceof javax.crypto.AEADBadTagException) showError("Giải mã thất bại: sai Key hoặc bản mã bị sửa.");
                    else if (cause instanceof java.sql.SQLException) showError("Không thực hiện được thao tác SQL Server. Kiểm tra kết nối và quyền truy cập.");
                    else if (cause instanceof IllegalArgumentException) showError(cause.getMessage());
                    else showError("Xử lý thất bại: sai Key, IV hoặc dữ liệu bị hỏng.");
                } finally {
                    processing = false;
                    enableInputs(panel_main, true);
                }
            }
        }.execute();
    }
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            java.awt.Toolkit.getDefaultToolkit().beep();
        }
        java.awt.EventQueue.invokeLater(() -> new frm_Menu().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_intro;
    private javax.swing.JButton btn_des;
    private javax.swing.JButton btn_tripledes;
    private javax.swing.JButton btn_aes;
    private javax.swing.JButton btn_rc4;
    private javax.swing.JButton btn_twofish;
    private javax.swing.JButton btn_aesctr;
    private javax.swing.JButton btn_sql;
    private javax.swing.JButton btn_history;
    private javax.swing.JLabel lbl_status;
}
